# Amor Verdadero (Forge 1.20.1)

Mod del amor: anillos, declaraciones, parejas que comparten destino.

## Cómo se juega
1. Craftea un anillo (Oro: 4 lingotes de oro en forma de anillo; Esmeralda/Diamante: anillo de oro + esmeralda/diamante).
2. Click derecho con el anillo sobre otro jugador (o `/amor proponer <jugador>`).
3. La otra persona recibe un aviso con botones [Aceptar] / [Rechazar].
   - Rechaza: empieza a llover y suena música triste; quien se declaró queda con el corazón roto.
   - Acepta: fuegos artificiales, cada uno recibe una Alianza de Amor y comparten destino.

## Pareja
- Alianza: click derecho = ir junto a tu pareja; agachado + click derecho = ver/usar su inventario.
- `/amor inventario`, `/amor enderchest`, `/amor tp`, `/amor sethogar`, `/amor hogar`, `/amor donde`, `/amor corazon`, `/amor decir <mensaje>`, `/amor estado`, `/amor divorcio`.
- Nivel de amor (sube pasando tiempo cerca y regalando Rosas del Amor): regeneración, velocidad, absorción, fuerza, resistencia y "Amor que salva" (revive una vez cada 10 min).
- Rosa del Amor y Bombón de Amor: regalos/comida con efectos.
