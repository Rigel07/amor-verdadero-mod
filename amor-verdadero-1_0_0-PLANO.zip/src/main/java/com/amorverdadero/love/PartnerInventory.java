package com.amorverdadero.love;

import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Vista (en un cofre de 5 filas) del inventario real de la pareja.
 * Filas 1-3: mochila. Fila 4: barra rápida. Fila 5: casco, peto, pantalones, botas, mano secundaria.
 * Los 4 huecos sobrantes de la fila 5 devuelven los objetos a quien los puso al cerrar.
 */
public class PartnerInventory implements Container {
    private final ServerPlayer owner;
    private final NonNullList<ItemStack> extra = NonNullList.withSize(4, ItemStack.EMPTY);

    public PartnerInventory(ServerPlayer owner) {
        this.owner = owner;
    }

    /** Traduce el hueco del cofre al índice del inventario real, o -1 si es un hueco sobrante. */
    private static int map(int slot) {
        if (slot < 27) return slot + 9;
        if (slot < 36) return slot - 27;
        if (slot < 40) return 39 - (slot - 36);
        if (slot == 40) return 40;
        return -1;
    }

    @Override
    public int getContainerSize() {
        return 45;
    }

    @Override
    public boolean isEmpty() {
        for (int i = 0; i < 45; i++) {
            if (!getItem(i).isEmpty()) return false;
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        int i = map(slot);
        if (i >= 0) return owner.getInventory().getItem(i);
        return extra.get(slot - 41);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        int i = map(slot);
        if (i >= 0) return owner.getInventory().removeItem(i, amount);
        return ContainerHelper.removeItem(extra, slot - 41, amount);
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        int i = map(slot);
        if (i >= 0) return owner.getInventory().removeItemNoUpdate(i);
        return ContainerHelper.takeItem(extra, slot - 41);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        int i = map(slot);
        if (i >= 0) owner.getInventory().setItem(i, stack);
        else extra.set(slot - 41, stack);
    }

    @Override
    public void setChanged() {
        owner.getInventory().setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return !owner.isRemoved();
    }

    @Override
    public void stopOpen(Player player) {
        for (int i = 0; i < extra.size(); i++) {
            ItemStack s = extra.get(i);
            if (!s.isEmpty()) {
                player.getInventory().placeItemBackInInventory(s);
                extra.set(i, ItemStack.EMPTY);
            }
        }
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < extra.size(); i++) extra.set(i, ItemStack.EMPTY);
    }
}
