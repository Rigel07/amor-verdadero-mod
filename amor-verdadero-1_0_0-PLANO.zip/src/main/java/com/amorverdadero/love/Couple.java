package com.amorverdadero.love;

import net.minecraft.nbt.CompoundTag;

import java.util.UUID;

public class Couple {
    /** Puntos necesarios para cada nivel (nivel 1 = índice 0). */
    public static final int[] LEVEL_POINTS = {0, 100, 300, 700, 1500};

    public UUID a;
    public UUID b;
    public String nameA = "?";
    public String nameB = "?";
    public long since;
    public int points;
    public boolean hasHome;
    public String homeDim = "minecraft:overworld";
    public double hx, hy, hz;
    public float hyaw;

    public Couple(UUID a, UUID b, String nameA, String nameB, long since, int points) {
        this.a = a;
        this.b = b;
        this.nameA = nameA;
        this.nameB = nameB;
        this.since = since;
        this.points = points;
    }

    public UUID other(UUID me) {
        return me.equals(a) ? b : a;
    }

    public String otherName(UUID me) {
        return me.equals(a) ? nameB : nameA;
    }

    public void setName(UUID id, String name) {
        if (id.equals(a)) nameA = name;
        else if (id.equals(b)) nameB = name;
    }

    public boolean has(UUID id) {
        return a.equals(id) || b.equals(id);
    }

    public int level() {
        return levelForPoints(points);
    }

    public static int levelForPoints(int p) {
        int lvl = 1;
        for (int i = 0; i < LEVEL_POINTS.length; i++) {
            if (p >= LEVEL_POINTS[i]) lvl = i + 1;
        }
        return lvl;
    }

    /** Puntos necesarios para el siguiente nivel, o -1 si ya está al máximo. */
    public int nextLevelPoints() {
        int lvl = level();
        return lvl >= LEVEL_POINTS.length ? -1 : LEVEL_POINTS[lvl];
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("a", a);
        t.putUUID("b", b);
        t.putString("nameA", nameA);
        t.putString("nameB", nameB);
        t.putLong("since", since);
        t.putInt("points", points);
        t.putBoolean("hasHome", hasHome);
        t.putString("homeDim", homeDim);
        t.putDouble("hx", hx);
        t.putDouble("hy", hy);
        t.putDouble("hz", hz);
        t.putFloat("hyaw", hyaw);
        return t;
    }

    public static Couple load(CompoundTag t) {
        Couple c = new Couple(t.getUUID("a"), t.getUUID("b"), t.getString("nameA"), t.getString("nameB"),
                t.getLong("since"), t.getInt("points"));
        c.hasHome = t.getBoolean("hasHome");
        c.homeDim = t.getString("homeDim");
        c.hx = t.getDouble("hx");
        c.hy = t.getDouble("hy");
        c.hz = t.getDouble("hz");
        c.hyaw = t.getFloat("hyaw");
        return c;
    }
}
