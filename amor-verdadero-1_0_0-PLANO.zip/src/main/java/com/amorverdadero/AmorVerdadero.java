package com.amorverdadero;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AmorVerdadero.MODID)
public class AmorVerdadero {
    public static final String MODID = "amorverdadero";

    public AmorVerdadero() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
