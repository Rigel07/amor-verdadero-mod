package com.amorverdadero;

import com.amorverdadero.item.BondRingItem;
import com.amorverdadero.item.LoveChocolateItem;
import com.amorverdadero.item.LoveRoseItem;
import com.amorverdadero.item.ProposalRingItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AmorVerdadero.MODID);

    public static final RegistryObject<Item> GOLD_RING = ITEMS.register("anillo_oro",
            () -> new ProposalRingItem(new Item.Properties().stacksTo(16), 0));
    public static final RegistryObject<Item> EMERALD_RING = ITEMS.register("anillo_esmeralda",
            () -> new ProposalRingItem(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON), 1));
    public static final RegistryObject<Item> DIAMOND_RING = ITEMS.register("anillo_diamante",
            () -> new ProposalRingItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE), 2));

    public static final RegistryObject<Item> BOND_RING = ITEMS.register("alianza",
            () -> new BondRingItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> LOVE_ROSE = ITEMS.register("rosa_del_amor",
            () -> new LoveRoseItem(new Item.Properties()));

    public static final RegistryObject<Item> LOVE_CHOCOLATE = ITEMS.register("bombon_de_amor",
            () -> new LoveChocolateItem(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(6).saturationMod(0.8F).alwaysEat().build())));
}
